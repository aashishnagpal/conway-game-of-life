# Conway's Game of Life

- Extract the zipped folder as is. Make sure you have AngularJS directory at the top level within which the folders named 'app' and 'test' are there. 
- Navigate to /AngularJS/app/ folder and run index.html **_Make Sure to RUN this file using Firefox Browser ONLY_**.
- All the instructions to work through the app are mentioned on the page itself, once you have the app running in the browser.
- You can see the test runs from within the running application. Just see the instructions at the bottom of the page.

